// tiny client-side validation helper
(function () {
    var form = document.getElementById('appointmentForm');
    if (!form) return;
    form.addEventListener('submit', function (e) {
        // use built-in HTML5 validation
        if (!form.checkValidity()) {
            e.preventDefault();
            alert('Please fill all required fields correctly.');
        }
    });
})();
