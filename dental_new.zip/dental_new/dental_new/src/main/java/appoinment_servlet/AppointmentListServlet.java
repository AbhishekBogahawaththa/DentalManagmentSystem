package appoinment_servlet;

import appoinmentController.appoinmentController;
import appoinmentModel.appoinmentModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/appointments/list")
public class AppointmentListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            List<appoinmentModel> list = appoinmentController.findAll();
            req.setAttribute("appointments", list);
            req.getRequestDispatcher("/appointments/list.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("errorMessage", "Failed to load appointments: " + e.getMessage());
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
        }
    }
}
