package appoinment_servlet;

import appoinmentController.appoinmentController;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/appointments/delete")
public class AppointmentDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String idStr = req.getParameter("id");
        if (idStr == null) {
            req.setAttribute("errorMessage", "Missing appointment id.");
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
            return;
        }
        try {
            int id = Integer.parseInt(idStr);
            boolean ok = appoinmentController.delete(id);
            if (ok) {
                resp.sendRedirect(req.getContextPath() + "/appointments/list");
            } else {
                req.setAttribute("errorMessage", "Appointment not found or already deleted.");
                req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
            }
        } catch (NumberFormatException e) {
            req.setAttribute("errorMessage", "Invalid appointment id: " + idStr);
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("errorMessage", "Delete failed: " + e.getMessage());
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
        }
    }
}
