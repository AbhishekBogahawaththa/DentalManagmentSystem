package appoinment_servlet;

import appoinmentController.appoinmentController;
import appoinmentModel.appoinmentModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@WebServlet("/appointments/edit")
public class AppointmentEditServlet extends HttpServlet {
    private static final DateTimeFormatter HTML_DT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String idStr = req.getParameter("id");
        if (idStr == null) {
            req.setAttribute("errorMessage", "Missing appointment id.");
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
            return;
        }
        try {
            int id = Integer.parseInt(idStr);
            appoinmentModel model = appoinmentController.getById(id);
            if (model == null) {
                req.setAttribute("errorMessage", "Appointment not found.");
                req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
                return;
            }
            req.setAttribute("appointment", model);           // prefill form.jsp
            req.getRequestDispatcher("/appointments/form.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("errorMessage", "Failed to load: " + e.getMessage());
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            req.setCharacterEncoding("UTF-8");
            int id = Integer.parseInt(req.getParameter("id"));
            String name  = req.getParameter("PatientName");
            String phone = req.getParameter("ContactNumber");
            String email = req.getParameter("Email");
            String dtStr = req.getParameter("AppointmentDateTime");
            if (isBlank(name)||isBlank(phone)||isBlank(email)||isBlank(dtStr)) {
                req.setAttribute("errorMessage", "All fields are required.");
                req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
                return;
            }
            LocalDateTime at = LocalDateTime.parse(dtStr, HTML_DT);

            appoinmentModel m = new appoinmentModel();
            m.setAppointment_id(id);
            m.setPatientName(name);
            m.setContactNumber(phone);
            m.setEmail(email);
            m.setAppointmentDateTime(at);

            boolean ok = appoinmentController.update(m);
            if (ok) {
                resp.sendRedirect(req.getContextPath() + "/appointments/list");
            } else {
                req.setAttribute("errorMessage", "Update failed.");
                req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("errorMessage", "Failed to update: " + e.getMessage());
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
        }
    }
    private boolean isBlank(String s){ return s==null || s.trim().isEmpty(); }
}
