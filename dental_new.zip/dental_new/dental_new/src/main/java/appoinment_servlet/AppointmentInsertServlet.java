package appoinment_servlet;

import appoinmentController.appoinmentController;
import appoinmentModel.appoinmentModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@WebServlet("/AppointmentInsertServlet")
public class AppointmentInsertServlet extends HttpServlet {
    private static final DateTimeFormatter HTML_DT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            req.setCharacterEncoding("UTF-8");
            String name  = req.getParameter("PatientName");
            String phone = req.getParameter("ContactNumber");
            String email = req.getParameter("Email");
            String dtStr = req.getParameter("AppointmentDateTime");
            if (isBlank(name) || isBlank(phone) || isBlank(email) || isBlank(dtStr)) {
                req.setAttribute("errorMessage", "All fields are required.");
                req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
                return;
            }
            LocalDateTime at = LocalDateTime.parse(dtStr, HTML_DT);
            appoinmentModel m = new appoinmentModel(name, phone, email, at);
            boolean ok = appoinmentController.insert(m);
            if (ok) {
                req.getRequestDispatcher("/appointment/done.jsp").forward(req, resp);
            } else {
                req.setAttribute("errorMessage", "Could not save the appointment.");
                req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("errorMessage", "Internal Server Error: " + e.getMessage());
            req.getRequestDispatcher("/wrong.jsp").forward(req, resp);
        }
    }
    private boolean isBlank(String s){ return s==null || s.trim().isEmpty(); }
}
