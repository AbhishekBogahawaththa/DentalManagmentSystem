package appoinmentModel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class appoinmentModel {
    private Integer appointment_id;
    private String patientName;
    private String contactNumber;
    private String email;
    private LocalDateTime appointmentDateTime;

    private static final DateTimeFormatter HTML_DT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    public appoinmentModel() {}

    public appoinmentModel(String patientName, String contactNumber, String email, LocalDateTime appointmentDateTime) {
        this.patientName = patientName;
        this.contactNumber = contactNumber;
        this.email = email;
        this.appointmentDateTime = appointmentDateTime;
    }

    public appoinmentModel(Integer appointment_id, String patientName, String contactNumber,
                           String email, LocalDateTime appointmentDateTime) {
        this(patientName, contactNumber, email, appointmentDateTime);
        this.appointment_id = appointment_id;
    }

    // getters
    public Integer getAppointment_id() { return appointment_id; }
    public String getPatientName() { return patientName; }
    public String getContactNumber() { return contactNumber; }
    public String getEmail() { return email; }
    public LocalDateTime getAppointmentDateTime() { return appointmentDateTime; }

    // setters (needed for edit)
    public void setAppointment_id(Integer appointment_id) { this.appointment_id = appointment_id; }
    public void setPatientName(String patientName) { this.patientName = patientName; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public void setEmail(String email) { this.email = email; }
    public void setAppointmentDateTime(LocalDateTime appointmentDateTime) { this.appointmentDateTime = appointmentDateTime; }

    // helpful for <input type="datetime-local">
    public String getFormattedDateTime() {
        return appointmentDateTime != null ? appointmentDateTime.format(HTML_DT) : "";
    }
}
