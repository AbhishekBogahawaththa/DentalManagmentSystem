package appoinmentController;

import appoinmentModel.appoinmentModel;
import util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class appoinmentController {

    // CREATE
    public static boolean insert(appoinmentModel m) throws Exception {
        final String sql = "INSERT INTO appointment " +
                "(PatientName, ContactNumber, Email, AppointmentDateTime) " +
                "VALUES (?, ?, ?, ?)";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getPatientName());
            ps.setString(2, m.getContactNumber());
            ps.setString(3, m.getEmail());
            ps.setTimestamp(4, Timestamp.valueOf(m.getAppointmentDateTime()));
            return ps.executeUpdate() == 1;
        }
    }

    // READ (all)
    public static List<appoinmentModel> findAll() throws Exception {
        final String sql = "SELECT Appointment_id, PatientName, ContactNumber, Email, AppointmentDateTime " +
                "FROM appointment ORDER BY AppointmentDateTime DESC";
        List<appoinmentModel> out = new ArrayList<>();
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new appoinmentModel(
                        rs.getInt("Appointment_id"),
                        rs.getString("PatientName"),
                        rs.getString("ContactNumber"),
                        rs.getString("Email"),
                        rs.getTimestamp("AppointmentDateTime").toLocalDateTime()
                ));
            }
        }
        return out;
    }

    // READ (one)
    public static appoinmentModel getById(int id) throws Exception {
        final String sql = "SELECT Appointment_id, PatientName, ContactNumber, Email, AppointmentDateTime " +
                "FROM appointment WHERE Appointment_id = ?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new appoinmentModel(
                            rs.getInt("Appointment_id"),
                            rs.getString("PatientName"),
                            rs.getString("ContactNumber"),
                            rs.getString("Email"),
                            rs.getTimestamp("AppointmentDateTime").toLocalDateTime()
                    );
                }
            }
        }
        return null;
    }

    // UPDATE
    public static boolean update(appoinmentModel m) throws Exception {
        final String sql = "UPDATE appointment SET " +
                "PatientName = ?, ContactNumber = ?, Email = ?, AppointmentDateTime = ? " +
                "WHERE Appointment_id = ?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getPatientName());
            ps.setString(2, m.getContactNumber());
            ps.setString(3, m.getEmail());
            ps.setTimestamp(4, Timestamp.valueOf(m.getAppointmentDateTime()));
            ps.setInt(5, m.getAppointment_id());
            return ps.executeUpdate() == 1;
        }
    }

    // DELETE
    public static boolean delete(int id) throws Exception {
        final String sql = "DELETE FROM appointment WHERE Appointment_id = ?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }
}
