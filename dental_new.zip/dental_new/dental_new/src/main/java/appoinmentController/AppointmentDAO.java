package appoinmentController;

import appoinmentModel.appoinmentModel;
import util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    public boolean insert(appoinmentModel m) throws Exception {
        final String sql =
                "INSERT INTO appointments (patient_name, contact_number, email, appointment_datetime) " +
                        "VALUES (?, ?, ?, ?)";

        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getPatientName());
            ps.setString(2, m.getContactNumber());
            ps.setString(3, m.getEmail());
            ps.setTimestamp(4, Timestamp.valueOf(m.getAppointmentDateTime()));
            return ps.executeUpdate() == 1;
        }
    }

    public List<appoinmentModel> findAll() throws Exception {
        final String sql =
                "SELECT appointment_id, patient_name, contact_number, email, appointment_datetime " +
                        "FROM appointments ORDER BY appointment_datetime DESC";
        List<appoinmentModel> out = new ArrayList<>();

        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                out.add(new appoinmentModel(
                        rs.getInt("appointment_id"),
                        rs.getString("patient_name"),
                        rs.getString("contact_number"),
                        rs.getString("email"),
                        rs.getTimestamp("appointment_datetime").toLocalDateTime()
                ));
            }
        }
        return out;
    }

    /** NEW: get one by id (returns null if not found) */
    public appoinmentModel getById(int id) throws Exception {
        final String sql =
                "SELECT appointment_id, patient_name, contact_number, email, appointment_datetime " +
                        "FROM appointments WHERE appointment_id = ?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new appoinmentModel(
                            rs.getInt("appointment_id"),
                            rs.getString("patient_name"),
                            rs.getString("contact_number"),
                            rs.getString("email"),
                            rs.getTimestamp("appointment_datetime").toLocalDateTime()
                    );
                }
            }
        }
        return null;
    }

    /** NEW: update existing row; returns true if a row was updated */
    public boolean update(appoinmentModel m) throws Exception {
        final String sql =
                "UPDATE appointments " +
                        "SET patient_name = ?, contact_number = ?, email = ?, appointment_datetime = ? " +
                        "WHERE appointment_id = ?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getPatientName());
            ps.setString(2, m.getContactNumber());
            ps.setString(3, m.getEmail());
            ps.setTimestamp(4, Timestamp.valueOf(m.getAppointmentDateTime()));
            ps.setInt(5, m.getAppointment_id());
            return ps.executeUpdate() == 1;
        }
    }

    /** Already added earlier */
    public boolean delete(int id) throws Exception {
        final String sql = "DELETE FROM appointments WHERE appointment_id = ?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }
}
