package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

    // 👉 Point to your real schema
    private static final String URL =
            "jdbc:mysql://localhost:3306/dental_clinic_new"
                    + "?useUnicode=true&characterEncoding=UTF-8"
                    + "&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    // 👉 Use the MySQL user/password that works on your machine
    private static final String USER = "root";        // e.g. "root" or "dental"
    private static final String PASS = "#20030126#Dh";            // e.g. "" or "YourPassword"

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // MySQL 8+
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC driver not found", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
